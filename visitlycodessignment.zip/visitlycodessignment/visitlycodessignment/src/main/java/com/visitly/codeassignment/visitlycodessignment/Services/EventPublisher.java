package com.visitly.codeassignment.visitlycodessignment.Services;

public interface EventPublisher {
    void publishRegistrationEvent(String email);
    void publishLoginEvent(String email);
}
