package com.visitly.codeassignment.visitlycodessignment.Services;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("prod")
public class ProdEventPublisherService implements EventPublisher {

    private final RabbitTemplate rabbitTemplate;
    private final String exchange;
    private final String registrationKey;
    private final String loginKey;

    public ProdEventPublisherService(
            RabbitTemplate rabbitTemplate,
            @Value("${app.events.exchange}") String exchange,
            @Value("${app.events.registration.routingKey}") String registrationKey,
            @Value("${app.events.login.routingKey}") String loginKey) {

        this.rabbitTemplate = rabbitTemplate;
        this.exchange = exchange;
        this.registrationKey = registrationKey;
        this.loginKey = loginKey;
    }

    @Override
    public void publishRegistrationEvent(String email) {
        rabbitTemplate.convertAndSend(exchange, registrationKey, email);
    }

    @Override
    public void publishLoginEvent(String email) {
        rabbitTemplate.convertAndSend(exchange, loginKey, email);
    }
}
