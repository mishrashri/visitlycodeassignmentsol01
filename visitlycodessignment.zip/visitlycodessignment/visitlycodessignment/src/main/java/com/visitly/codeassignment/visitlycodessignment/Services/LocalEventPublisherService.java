package com.visitly.codeassignment.visitlycodessignment.Services;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("local")
public class LocalEventPublisherService implements EventPublisher {

    @Override
    public void publishRegistrationEvent(String email) {
        System.out.println("[LOCAL] Skipping RabbitMQ registration event for: " + email);
    }

    @Override
    public void publishLoginEvent(String email) {
        System.out.println("[LOCAL] Skipping RabbitMQ login event for: " + email);
    }
}
