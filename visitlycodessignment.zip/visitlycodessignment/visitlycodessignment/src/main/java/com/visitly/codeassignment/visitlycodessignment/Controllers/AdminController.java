package com.visitly.codeassignment.visitlycodessignment.Controllers;

import com.visitly.codeassignment.visitlycodessignment.Repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    private final UserRepository userRepository;

    public AdminController(UserRepository ur) {
        this.userRepository = ur;
    }

    @GetMapping("/stats")
    @PreAuthorize("hasAuthority('ADMIN')")
    public Map<String, Object> stats() {
        long total = userRepository.count();
        // last login times - return mocked or small sample
        return Map.of("totalUsers", total, "generatedAt", java.time.Instant.now().toString());
    }
}
