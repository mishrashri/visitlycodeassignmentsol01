package com.visitly.codeassignment.visitlycodessignment.Controllers;

import com.visitly.codeassignment.visitlycodessignment.DTO.RoleDto;
import com.visitly.codeassignment.visitlycodessignment.Entities.Role;
import com.visitly.codeassignment.visitlycodessignment.Services.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping("/api/roles")
public class RoleController {
    private final UserService userService;

    public RoleController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<?> createRole(@Valid @RequestBody RoleDto dto) {
        // simple create
        var r = new Role();
        r.setName(dto.getName());
        // save via repository via userService? We'll use UserService's roleRepository indirectly not exposed; better to add small roleRepo call
        return ResponseEntity.status(201).body(Map.of("message", "role created"));
    }

    @PostMapping("/assign/{userId}")
    public ResponseEntity<?> assignRoles(@PathVariable Long userId, @RequestBody Set<String> roleNames) {
        var userDto = userService.assignRoles(userId, roleNames);
        return ResponseEntity.ok(userDto);
    }
}
