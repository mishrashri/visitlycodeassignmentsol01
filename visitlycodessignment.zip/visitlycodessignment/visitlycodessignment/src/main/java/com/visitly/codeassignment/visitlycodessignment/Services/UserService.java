package com.visitly.codeassignment.visitlycodessignment.Services;

import com.visitly.codeassignment.visitlycodessignment.DTO.UserDto;
import com.visitly.codeassignment.visitlycodessignment.Entities.Role;
import com.visitly.codeassignment.visitlycodessignment.Entities.User;
import com.visitly.codeassignment.visitlycodessignment.Repository.RoleRepository;
import com.visitly.codeassignment.visitlycodessignment.Repository.UserRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;

    public UserService(UserRepository ur, RoleRepository rr) {
        this.userRepository = ur;
        this.roleRepository = rr;
    }

    public UserDto toDto(User u) {
        UserDto dto = new UserDto();
        dto.setId(u.getId());
        dto.setUsername(u.getUsername());
        dto.setEmail(u.getEmail());
        dto.setRoles(u.getRoles().stream().map(Role::getName).collect(Collectors.toSet()));
        return dto;
    }

    public UserDto getByEmail(String email) {
        User user = userRepository.findByEmail(email).orElseThrow();
        return toDto(user);
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @Transactional
    public UserDto assignRoles(Long userId, Set<String> roleNames) {
        User user = userRepository.findById(userId).orElseThrow();
        for (String rn : roleNames) {
            Role r = roleRepository.findByName(rn).orElseGet(() -> {
                Role nr = new Role();
                nr.setName(rn);
                return roleRepository.save(nr);
            });
            user.getRoles().add(r);
        }
        userRepository.save(user);
        return toDto(user);
    }
}
