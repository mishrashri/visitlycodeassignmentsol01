package com.visitly.codeassignment.visitlycodessignment.Security;

import org.springframework.stereotype.Service;

@Service
public class CustomUserDetailsService {
    // Minimal service; for this assignment the filter uses JwtProvider directly for roles and subject
}
