package com.visitly.codeassignment.visitlycodessignment.Services;

import com.visitly.codeassignment.visitlycodessignment.DTO.LoginRequest;
import com.visitly.codeassignment.visitlycodessignment.DTO.RegisterRequest;
import com.visitly.codeassignment.visitlycodessignment.Entities.Role;
import com.visitly.codeassignment.visitlycodessignment.Entities.User;
import com.visitly.codeassignment.visitlycodessignment.Repository.RoleRepository;
import com.visitly.codeassignment.visitlycodessignment.Repository.UserRepository;
import com.visitly.codeassignment.visitlycodessignment.Security.JwtProvider;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final JwtProvider jwtProvider;
    private final EventPublisher eventPublisher;

    public AuthService(UserRepository userRepository,
                       RoleRepository roleRepository,
                       BCryptPasswordEncoder passwordEncoder,
                       JwtProvider jwtProvider,
                       EventPublisher eventPublisher) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtProvider = jwtProvider;
        this.eventPublisher = eventPublisher;
    }

    @Transactional
    public String register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Email already in use");
        }

        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));

        // default role USER
        Role userRole = roleRepository.findByName("USER")
                .orElseGet(() -> {
                    Role r = new Role();
                    r.setName("USER");
                    return roleRepository.save(r);
                });

        user.getRoles().add(userRole);
        userRepository.save(user);

        // publish registration event
        eventPublisher.publishRegistrationEvent(user.getEmail());

        return "registered";
    }

    @Transactional
    public String login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new IllegalArgumentException("Invalid credentials");
        }

        user.setLastLoginAt(Instant.now());
        userRepository.save(user);

        Set<String> roles = user.getRoles().stream().map(Role::getName).collect(Collectors.toSet());
        String token = jwtProvider.generateToken(user.getEmail(), roles);

        // publish login event
        eventPublisher.publishLoginEvent(user.getEmail());

        return token;
    }
}
