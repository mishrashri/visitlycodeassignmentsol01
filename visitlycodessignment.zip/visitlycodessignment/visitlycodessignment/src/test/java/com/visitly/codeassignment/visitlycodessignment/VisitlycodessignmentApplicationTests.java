package com.visitly.codeassignment.visitlycodessignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisitlycodessignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
